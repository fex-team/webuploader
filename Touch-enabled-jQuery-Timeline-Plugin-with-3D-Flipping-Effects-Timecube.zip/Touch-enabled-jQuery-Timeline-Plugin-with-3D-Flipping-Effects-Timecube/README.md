# Swipable / Clickable timeline

## Use 
Expects data similar to timecube.example.js
